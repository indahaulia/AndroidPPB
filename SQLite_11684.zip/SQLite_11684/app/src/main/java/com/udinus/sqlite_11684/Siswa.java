package com.udinus.sqlite_11684;

public class Siswa {
    String nim;
    String nama_siswa;

    public Siswa(){

    }

    public String getNim(){
        return nim;
    }

    public void Setnim(String nim){
        this.nim = nim;
    }

    public String getNama_siswa(){
        return nama_siswa;
    }

    public void SetNama_siswa(String nama_siswa){
        this.nama_siswa = nama_siswa;

    }
}
